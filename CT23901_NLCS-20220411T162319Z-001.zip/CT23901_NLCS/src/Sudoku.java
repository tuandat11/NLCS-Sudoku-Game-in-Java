/* 
    * Niên luận Cơ sở ngành
    * CT239-01
    * B1805749 - Trần Tuấn Đạt
*/

// Thêm các thư viện cần thiết
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import javax.swing.JFrame;

public class Sudoku {
    
    //Khai báo các biến của chương trình
    static JFrame frame;
    static Board b;
    private static int[][] grid;                //Mảng lưu ma trận đã giải
    private static int[][] temp;                //Mảng lưu ma trận đề
    private static Random ran = new Random();   
    private static int level = 2;               //Giá trị level mặc nhiên khi khởi chạy là 2 tương ứng với level Dễ

    //Hàm tạo ma trận mới cho ván game mới
    public static void newGame() {
        int k = 0;
        ArrayList<Integer> randomnumber = getRandomNum();
        
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                grid[i][j] = 0;
                if (((j + 2) % 2) == 0 && ((i + 2) % 2) == 0) {
                    grid[i][j] = randomnumber.get(k);
                    k++;
                    if (k == 9) {
                        k = 0;
                    }
                }
            }
        }
        search(grid);
        int rann = ran.nextInt(level);
        int c = 0;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                temp[i][j] = 0;
                if (c < rann) {
                    c++;
                    continue;
                } else {
                    rann = ran.nextInt(level);
                    c = 0;
                    temp[i][j] = grid[i][j];
                }
            }
        }
        b.setarray(grid, temp);
        b.setTextLable();
    }

    //Hàm lấy về danh sách các ô trống
    public static int[][] getList_otrong(int[][] grid) {
        int slotrong = 0;       //Biến đếm số ô trống
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (grid[i][j] == 0) {
                    slotrong++;
                }
            }
        }
        int[][] list_otrong = new int[slotrong][2];     //Mảng lưu danh sách ô trống
        int count = 0;
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (grid[i][j] == 0) {
                    list_otrong[count][0] = i;
                    list_otrong[count][1] = j;
                    count++;
                }
            }
        }
        return list_otrong;
    }

    //Hàm giải Soduku theo thuật toán Quay lui vét cạn.
    public static boolean search(int[][] grid) {
        int[][] list_otrong = getList_otrong(grid);
        int k = 0;
        boolean found = false;
        while(!found) {
            int i = list_otrong[k][0];
            int j = list_otrong[k][1];
            if (grid[i][j] == 0) {
                grid[i][j] = 1;
            }
            if (valid(i, j, grid)) {
                if (k + 1 == list_otrong.length) {
                    found = true;
                } else {
                    k++;
                }
            }
            else if (grid[i][j] < 9) {
                grid[i][j] = grid[i][j] + 1;
            } 
            else {
                while (grid[i][j] == 9) {
                    grid[i][j] = 0;
                    if (k == 0) {
                        return false;
                    }
                    k--; 
                    i = list_otrong[k][0];
                    j = list_otrong[k][1];
                }
                grid[i][j] = grid[i][j] + 1;
            }
        }
        return true;
    }

    //Hàm kiểm tra giá trị nhập vào có hợp lệ hay không
    public static boolean valid(int i, int j, int[][] grid) {
        // Kiểm tra hàng
        for (int column = 0; column < 9; column++) {
            if (column != j && grid[i][column] == grid[i][j]) {
                return false;
            }
        }
        // Kiểm tra cột
        for (int row = 0; row < 9; row++) {
            if (row != i && grid[row][j] == grid[i][j]) {
                return false;
            }
        }
        // Kiểm tra khối 3 x 3
        for (int row = (i / 3) * 3; row < (i / 3) * 3 + 3; row++) {
            for (int col = (j / 3) * 3; col < (j / 3) * 3 + 3; col++) {
                if (row != i && col != j && grid[row][col] == grid[i][j]) {
                    return false;
                }
            }
        }
        return true; 
    }
    
    //Hàm tạo List chứa các số random
    public static ArrayList<Integer> getRandomNum() {
        ArrayList<Integer> numbers = new ArrayList<Integer>();
        for (Integer i = 1; i < 10; i++) {
            numbers.add(i);
        }
        Collections.shuffle(numbers);
        return numbers;
    }

    //Hàm gán giá trị level
    public static void setlevel(int lev) {
        level = lev;
    }
    
    public static void main(String[] args) {
        grid = new int[9][9];
        temp = new int[9][9];
        frame = new JFrame();
        frame.setResizable(false);
        frame.setLocation(320, 40);
        frame.setSize(650, 650);
        frame.setTitle("Niên luận cơ sở ngành CT23901 - Sudoku");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        b = new Board();
        frame.setContentPane(b);
        frame.setVisible(true);
    }
}


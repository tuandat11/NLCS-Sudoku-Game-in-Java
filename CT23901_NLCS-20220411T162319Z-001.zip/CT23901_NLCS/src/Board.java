/* 
    * Niên luận Cơ sở ngành
    * CT239-01
    * B1805749 - Trần Tuấn Đạt
*/

//Khai báo các thư viện cần thiết
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Board extends javax.swing.JPanel {
    //Khai báo các biến 
    Sudoku game;
    private static JTextField[][] o;
    private static JPanel[][] paneles;
    private JPanel panMain,     //Panel chính chứa giao diện của chương trình
                   panControll, //Panel điều khiển chứa các nút lệnh
                   panBoard;    //Panel bảng chứa ma trận Sudoku
    
    private JButton btnNew, btnCheck, btnSolve,
                    btnReset, btnExit, btnSave;         //Các button điều khiển chương trình
    private JRadioButton btnEasy, btnMid, btnHard;      //Các button level
    
    private String level = "Dễ";                        //Biến dùng để lưu tên của level dùng để xuất ra tệp
   
    private int[][] temp = new int[9][9];   //Mảng lưu ma trận đề
    private int[][] grid = new int[9][9];   //Mảng lưu ma trận đã giải


    public JTextField newtextfield() {
        JTextField j = new JTextField("");
        j.setBorder(BorderFactory.createLineBorder(Color.lightGray));
        j.setFont(new Font(Font.DIALOG, Font.PLAIN, 25));
        j.setHorizontalAlignment(JTextField.CENTER);
        
        //Sự kiện đổi màu khi ô được chuột trỏ vào để nhận biết
        j.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (j.isEditable()) {
                    ((JTextField) e.getSource()).setBorder(BorderFactory.createLineBorder(Color.decode("#00F5FF")));
                    ((JTextField) e.getSource()).setBackground(Color.decode("#00F5FF"));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (j.isEditable()) {
                    ((JTextField) e.getSource()).setBorder(BorderFactory.createLineBorder(Color.lightGray));
                    ((JTextField) e.getSource()).setBackground(Color.white);
                }
            }
        });
        
        /*------------------------------------------------*/
        j.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (j.isEditable()) {
                    ((JTextField) e.getSource()).setForeground(Color.decode("#0c4"));
                } else {
                    ((JTextField) e.getSource()).setForeground(Color.black);
                }
            }
        });
        return j;
    }
    
    public Board() {
        initComponents();
        //Cài đặt giao diện của panel chính
        panMain = new JPanel();  
        panMain.setLayout(new GridLayout(3, 3));      
        panMain.setBackground(Color.BLACK);
        setLayout(new BorderLayout());
        add(panMain);   
        o = new JTextField[9][9];
        paneles = new JPanel[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                paneles[i][j] = new JPanel();
                paneles[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                paneles[i][j].setLayout(new GridLayout(3, 3));
                panMain.add(paneles[i][j]);
            }
        }
        //Thêm ô textfield vào các khối 3x3
        for (int n = 0; n < 9; n++) {
            for (int i = 0; i < 9; i++) {
                o[n][i] = newtextfield();
                int fm = (n + 1) / 3;
                if ((n + 1) % 3 > 0) 
                    fm++;
                int cm = (i + 1) / 3;
                if ((i + 1) % 3 > 0) 
                    cm++;
                paneles[fm - 1][cm - 1].add(o[n][i]);    
            }
        }
        
        /*---------------------------------------------------------------------------*/
        //Cài đặt Panel chứa các button điều khiển
        panControll = new JPanel();
        panControll.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panControll.setLayout(new GridLayout(3, 3, 40, 10));
   
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt button btnNew - ván mới
            - Khi click vào button này, ma trận mới cho level đang chọn sẽ hiện ra thay thế ma trận cũ
        */
        btnNew = new JButton("VÁN MỚI");
        btnNew.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {                
                refresh();
                Sudoku.newGame();
                mokhoabutton();
                btnSave.setEnabled(false);
            }
        });

        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt button btnCheck - KIỂM TRA giá trị nhập vào các ô trống
            - Khi click vào button này, bảng ma trận sẽ đổi màu background tại các ô trống do người dùng nhập vào với
                + Màu xanh: giá trị nhập vào tại ô đó đúng.
                + Màu đỏ: giá trị nhập vào tại ô đó không hợp lệ (trùng số theo quy tắc, sai định dạng số tự nhiên không âm 1-9, ...).
                + Màu trắng (ô không đổi màu): chưa có giá trị tại thời điểm kiểm tra.
        */
        btnCheck = new JButton("KIỂM TRA");
        btnCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        if (!o[i][j].isEditable()) {
                            continue;
                        } else if (o[i][j].getText().equals(String.valueOf(grid[i][j]))) {
                            o[i][j].setBackground(Color.decode("#99FF00"));
                        } else if (o[i][j].getText().isEmpty()) {
                            o[i][j].setBackground(Color.WHITE);
                            continue;
                        } else {
                            o[i][j].setBackground(Color.RED);
                        }
                    }
                }
                if(win())   {
                    JOptionPane.showMessageDialog(null,"Chúc mừng, bạn đã xuất sắc giải đúng game Sudoku level " + level
                            + " này rồi!\n Hãy chơi ván mới hoặc thử sức với level cao hơn xem nào!");
                    btnSave.setEnabled(true);
                }
            }
        });
        
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt button btnExit - Thoát khỏi game
            - Khi click vào button này, chương trình sẽ hiện thông báo hỏi người dùng có chắc chắn muốn thoát,
              nếu người dùng chọn Yes, chương trình sẽ đóng lại
        */
        btnExit = new JButton("THOÁT");
        btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int click=JOptionPane.showConfirmDialog(null, "Bạn có muốn thoát chương trình hay không?", "Thông báo", 2);
                if(click==JOptionPane.YES_OPTION)
                    System.exit(0);
            }
        });

        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt radiobutton btnHard - Level khó
            - Khi click vào radiobutton này, ma trận mới sẽ xuất hiện tương ứng với level khó
        */
        btnHard = new JRadioButton("Khó");
        btnHard.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refresh();                
                Sudoku.setlevel(7);
                Sudoku.newGame();
                mokhoabutton();
                btnSave.setEnabled(false);
                level = "Khó";
            }
        });
        
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt radiobutton btnMid - Level trung bình
            - Khi click vào radiobutton này, ma trận mới sẽ xuất hiện tương ứng với level trung bình
        */
        btnMid = new JRadioButton("Trung bình");
        btnMid.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refresh();                 
                Sudoku.setlevel(4);
                Sudoku.newGame();
                mokhoabutton();
                btnSave.setEnabled(false);
                level = "Trung bình";
            }
        });
        
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt radiobutton btnEasy - Level đơn giản nhất
            - Khi click vào radiobutton này, ma trận mới sẽ xuất hiện tương ứng với level dễ
        */
        btnEasy = new JRadioButton("Dễ");
        btnEasy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refresh();                
                Sudoku.setlevel(2);
                Sudoku.newGame();
                mokhoabutton();
                btnSave.setEnabled(false);
                level = "Dễ";
            }
        });
        
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt button btnSolve - Giải ma trận
            - Khi click vào button này, tất cả các ô trống sẽ được điền vào, ma trận được giải quyết người chơi
              có thể lựa chọn chức năng LƯU để lưu ma trận này ra file txt
        */
        btnSolve = new JButton("ĐÁP ÁN");
        btnSolve.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        o[i][j].setText(String.valueOf(grid[i][j]));
                    }
                }
                btnSave.setEnabled(true);
                btnSolve.setEnabled(false);
                btnCheck.setEnabled(false);
            }
        });
        
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt button btnReset - Xóa sạch các giá trị người dùng đã  nhập vào để chơi lại
            - Khi click vào button này, tất cả các ô đã được người dùng điền vào sẽ được xóa sạch để chơi lại với ma trận cũ
        */
        btnReset = new JButton("CHƠI LẠI");
        btnReset.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reset();
            }
        });
        
        /*---------------------------------------------------------------------------*/
        /*
            - Cài đặt button btnSave - LƯU ma trận Sudoku
            - Khi click vào button này, ma trận đang giải sẽ được lưu dưới dạng file txt
        */
        btnSave = new JButton("LƯU");
        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                in(dinhdang());
                btnSave.setEnabled(false);
            }
        });
        
        /*---------------------------------------------------------------------------*/
        //Tạo nhóm cho các RadioButton để mỗi thời điểm chỉ chọn 1 level
        ButtonGroup btnLevel = new ButtonGroup(); 
        btnLevel.add(btnEasy);
        btnLevel.add(btnMid);
        btnLevel.add(btnHard);
        
        //Cài đặt mặc định khi khởi chạy chương trình là chọn Radiobutton level dễ
        btnEasy.setSelected(true);
        
        //Thêm các button điều khiển vào panel điều khiển
        panControll.add(btnEasy);
        panControll.add(btnMid);
        panControll.add(btnHard);
        panControll.add(btnNew);    
        panControll.add(btnReset);
        panControll.add(btnExit);
        panControll.add(btnCheck);
        panControll.add(btnSolve);
        panControll.add(btnSave);
        
        //Cài đặt khóa các button điều khiển Giải, KIỂM TRA, LƯU khi khởi chạy chương trình
        khoabutton();
        
        //Thêm panel điều khiển lên trên panel chính
        add(panControll, "North");   
    }

    /*---------------------------------------------------------------------------*/
    //Cài đặt 2 mảng ban đầu chứa ma trận
    public void setarray(int[][] grid, int[][] temp) {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                this.temp[i][j] = temp[i][j];
                this.grid[i][j] = grid[i][j];
            }
        }
    }

    //Gán giá trị vào các ô đề của ma trận Sudoku
    public void setTextLable() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (this.temp[i][j] != 0) {
                    o[i][j].setText(String.valueOf(this.temp[i][j]));
                    o[i][j].setEditable(false);
                    o[i][j].setBackground(Color.decode("#9FB6CD"));
                } else {
                    o[i][j].setText("");
                }
            }
        }
    }
    
    //Hàm đặt lại các ô của ma trận
    public static void refresh() {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                o[i][j].setForeground(Color.black);
                o[i][j].setEditable(true);
                o[i][j].setBackground(Color.WHITE);
            }
        }
    }
    
    //Hàm xóa hết các giá trị người dùng nhập vào để chơi lại với ma trận hiện tại
    public void reset() {
        refresh();
        setTextLable();
        btnSolve.setEnabled(true);
        btnCheck.setEnabled(true);
        btnSave.setEnabled(false);
    }
    

    //Hàm xuất ma trận ra file txt
    private void in(String dinhdang)   {
        //Tạo thư mục để lưu file outPut.
        String link = "D:\\CT23901_NLCS\\log\\";
        File vitriluu = new File(link);
        
        //KIỂM TRA thư mục lưu file đã tồn tại hay chưa, nếu chưa có thì tạo thư mục tương ứng với đường dẫn
        if(!vitriluu.exists())
            vitriluu.mkdir();
        
        try {
            Date dt = new Date();
            SimpleDateFormat d = new SimpleDateFormat("dd-MM-yyyy hh-mm-ss"); //Định dạng thời gian để lấy làm tên tệp phân biệt
            String time = d.format(dt);
            String tenfile = "Ma trận" +" ("+time+")".trim(); //Biến để lưu tên tệp
            System.out.println(tenfile);
            File fileDir = new File(link + tenfile + ".txt");
            try (Writer out = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(fileDir), "UTF8"))) {
                out.append(dinhdang);
                out.flush();
                out.close();
            }
            JOptionPane.showMessageDialog(null, tenfile + ".txt đã được lưu tại \n" +link + "\nBạn có thể xem lại!");
        }
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Lỗi đường dẫn thư mục lưu tập tin, cài đặt lại!");
            System.out.println(e.getMessage());
        }
    }
    
    //Định dạng cho nội dung file txt lưu ma trận được in ra
    private String dinhdang()   {
        Date dt = new Date();
        SimpleDateFormat d = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        String time = d.format(dt);
        
        String matran = "Thời gian: ";
        matran += time +="\n";
        matran += "Level: " + level +"\n\n";
                
        for(int i=0; i<9; i++) {  
            for (int j = 0; j < 9; j++) {
                matran+= temp[i][j] + "  "; 
            }
            matran += "\n";
        }
        
        matran += "\n      ************* \n";
    
        for(int i=0; i<9; i++) {  
            matran += "\n";
            for (int j = 0; j < 9; j++) {
                matran+= grid[i][j];
                matran += "  "; 
            }
        }
        return matran;     
    }
    
    // Hàm kiểm tra người chơi đã thắng hay chưa
    private boolean win()   {
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                if (!o[i][j].isEditable())  continue;
                else if (o[i][j].getText().equals(String.valueOf(grid[i][j]))) continue;
                else return false;
            }
        }
        return true;   
    }
    
    //Hàm khóa chức năng các button
    private void khoabutton()   {
        btnSave.setEnabled(false);
        btnSolve.setEnabled(false);
        btnCheck.setEnabled(false);
        btnReset.setEnabled(false);
    }
    
    //Hàm bật chức năng các button
    private void mokhoabutton() {
        btnSolve.setEnabled(true);
        btnCheck.setEnabled(true);
        btnReset.setEnabled(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
